#!/usr/bin/env bash
set -euo pipefail
# Extract raw.tar.gz into a disposable directory; run here with prepared compiler.
: "${WIRE_TSC:?Set WIRE_TSC to the prepared TypeScript 7.0.2 compiler}"
for variant in before after; do
  "$WIRE_TSC" --ignoreConfig --strict --noUncheckedIndexedAccess --exactOptionalPropertyTypes --target ES2022 --module CommonJS --skipLibCheck --outDir "$variant" "$variant/runtime.ts"
done
# Recorded Linux timing pins CPU 0. Other hosts may run node directly; label separately.
taskset -c 0 node --expose-gc bench.cjs
