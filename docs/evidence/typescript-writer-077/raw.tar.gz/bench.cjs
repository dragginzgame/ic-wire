const fs=require('fs'), assert=require('assert/strict'), crypto=require('crypto');
const {performance}=require('perf_hooks');
const before=require('./before/runtime.js'), after=require('./after/runtime.js');
const budget=2*1024*1024;
const cases=[];
function add(name,schema,value,limit=budget,direction='Request',invalid=false){
 const metadata={id:'123',request:schema,response:schema,requestBytes:limit,responseBytes:limit+1048576,requestNodes:1000000,responseNodes:1000000,requestDepth:64,responseDepth:64};
 const codecs=[before,after].map(m=>m.createCodec(metadata));
 const calls=codecs.map(c=>()=>{try{return c['encode'+direction](value);}catch(e){if(!invalid)throw e;return e.code;}});
 const expected=calls[0](); assert.deepEqual(calls[1](),expected);
 if(invalid)assert.equal(expected,'value');
 const hash=typeof expected==='string'?expected:crypto.createHash('sha256').update(expected).digest('hex');
 cases.push({name,metadata,calls,hash,bytes:typeof expected==='string'?0:expected.length});
}
add('unit-128',{k:'unit'},null,128);
add('unit-2MiB',{k:'unit'},null);
add('unit-response-3MiB',{k:'unit'},null,budget,'Response');
add('invalid-unit-2MiB',{k:'unit'},'invalid',budget,'Request',true);
add('scalar-128',{k:'u',bits:32},128,128);
for(const n of [0,32,4096,1048576]) add(`bytes-${n}`,{k:'bytes'},new Uint8Array(n).fill(42));
add('bytes-tight-4096',{k:'bytes'},new Uint8Array(4096).fill(42),4109);
for(const n of [0,32,4096])add(`ascii-${n}`,{k:'text'},'a'.repeat(n));
add('unicode-4096',{k:'text'},'é漢😀'.repeat(512));
for(const n of [0,32,4096,524288])add(`packed-i16-${n}`,{k:'packed',word:'i16'},new Int16Array(n).fill(32767));
for(const n of [32,4096,65536])add(`u32-list-${n}`,{k:'list',item:{k:'u',bits:32}},Array(n).fill(4294967295));
add('u32-list-tight-4096',{k:'list',item:{k:'u',bits:32}},Array(4096).fill(4294967295),20493);
add('floats-1000',{k:'list',item:{k:'float',bits:64}},Array.from({length:1000},(_,i)=>i+0.25));
const Original=global.Uint8Array;
let allocations;
class Observed extends Original {
 constructor(...args){super(...args);if(allocations && !(args[0] instanceof ArrayBuffer))allocations.push(this.byteLength);}
 static [Symbol.hasInstance](value){return value instanceof Original;}
}
const allocation=[];
for(const c of cases)for(let v=0;v<2;v++){
 allocations=[];global.Uint8Array=Observed;
 try{c.calls[v]();allocation.push({case:c.name,variant:['before','after'][v],requests:allocations,bytes:allocations.reduce((a,b)=>a+b,0),largest:Math.max(...allocations)});}
 finally{global.Uint8Array=Original;allocations=undefined;}
}
fs.writeFileSync('allocations.json',JSON.stringify(allocation,null,2));
fs.writeFileSync('inputs.json',JSON.stringify(cases.map(({name,metadata,hash,bytes})=>({name,metadata,hash,bytes})),null,2));
const rows=[];
function elapsed(call,n){const start=performance.now();for(let i=0;i<n;i++)global.lastEncoded=call();return (performance.now()-start)*1e6/n;}
for(let run=0;run<3;run++)for(const c of cases){
 const repetitions=c.calls.map(call=>{for(let i=0;i<1000;i++)call();let n=1;while(elapsed(call,n)*n<5e6 && n<65536)n*=2;return n;});
 for(let sample=0;sample<11;sample++)for(const v of ((sample+run)%2?[1,0]:[0,1])){
  if(global.gc)global.gc();
  rows.push({run,case:c.name,variant:['before','after'][v],sample,repetitions:repetitions[v],ns:elapsed(c.calls[v],repetitions[v])});
 }
}
fs.writeFileSync('samples.json',JSON.stringify(rows));
const median=a=>a.sort((a,b)=>a-b)[Math.floor(a.length/2)];
const csv=['case,before_ns,after_ns,percent,before_requested_bytes,after_requested_bytes'];
for(const c of cases){const med=['before','after'].map(v=>median(rows.filter(r=>r.case===c.name&&r.variant===v).map(r=>r.ns)));const alloc=['before','after'].map(v=>allocation.find(r=>r.case===c.name&&r.variant===v).bytes);csv.push([c.name,...med,100*(med[1]-med[0])/med[0],...alloc].join(','));}
fs.writeFileSync('summary.csv',csv.join('\n')+'\n');
console.log(csv.join('\n'));
