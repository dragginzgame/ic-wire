from pathlib import Path
import subprocess,json,hashlib,os
p=Path(__file__).parent;s=p/'source';base=(p/'native-before.rs').read_text();results=[]
for cohort,features in [('one','derive-scale-1'),('hundred','derive-scale')]:
 d=p/cohort;d.mkdir()
 for variant in ['baseline','candidate']:
  text=base if variant=='baseline' else (p/'native-candidate.rs').read_text()
  (s/'crates/ic-wire/src/native/mod.rs').write_text(text)
  for profile in ['evaluation','benchmark-speed']:
   label=profile+'-'+variant
   cmd=['cargo','build','--locked','--offline','-p','ic-wire-benchmarks','--example','codec-wasm','--target','wasm32-unknown-unknown','--profile',profile,'--features','wire'+(','+features if features else ''),'--message-format=json']
   with (d/(label+'.jsonl')).open('w') as log:subprocess.run(cmd,cwd=s,stdout=log,check=True,env=dict(os.environ,CARGO_TARGET_DIR=str(p/'target-wasm')))
   rows=[json.loads(x) for x in (d/(label+'.jsonl')).read_text().splitlines()]
   wasm=next(Path(f) for r in rows if r.get('reason')=='compiler-artifact' and r['target']['name']=='codec-wasm' for f in r['filenames'] if f.endswith('.wasm'))
   data=wasm.read_bytes();(d/(label+'-wire.wasm')).write_bytes(data)
   i=8;code=0
   while i<len(data):
    kind=data[i];i+=1;n=0;shift=0
    while True:
     b=data[i];i+=1;n|=(b&127)<<shift;shift+=7
     if b<128:break
    if kind==10:code=n
    i+=n
   result=dict(cohort=cohort,variant=variant,profile=profile,total=len(data),code=code,sha256=hashlib.sha256(data).hexdigest());results.append(result);print(result,flush=True)
   (p/'sizes.json').write_text(json.dumps(results,indent=2)+'\n')
