#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
run="$(mktemp -d "${TMPDIR:-/tmp}/wire-output-replay.XXXXXX")"
cp -R source "$run/source"
cp run.py native-before.rs native-candidate.rs "$run/"
python3 "$run/run.py"
printf 'Evidence: %s\n' "$run"
