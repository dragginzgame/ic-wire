#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
: "${POCKET_IC_BIN:?set an explicit prepared PocketIC server}"
run="$(mktemp -d "${TMPDIR:-/tmp}/wire-varint-replay.XXXXXX")"
cp -R source "$run/source"
cp run.py fast.py instructions.py parser-*.rs driver-*.rs "$run/"
cd "$run"
export CARGO_TARGET_DIR="$run/target-native"
python3 run.py
cp driver-candidate.rs source/crates/ic-wire-benchmarks/examples/instructions/mod.rs
cargo test --locked --offline --manifest-path source/Cargo.toml -p ic-wire --lib --test native
python3 instructions.py
python3 fast.py
cargo test --locked --offline --manifest-path source/Cargo.toml -p ic-wire --lib --test native
cp driver-fast.rs source/crates/ic-wire-benchmarks/examples/instructions/mod.rs
mkdir fast-standard
for profile in evaluation benchmark-speed; do
    for variant in baseline fast; do
        cp "standard/$profile-$variant-wire.wasm" fast-standard/
    done
done
cargo run --locked --offline --manifest-path source/Cargo.toml -p ic-wire-benchmarks --example codec-instructions --features wire,candid,ic -- "$run/fast-standard"
printf 'Evidence: %s\n' "$run"
