#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export CARGO_TARGET_DIR="$PWD/target"
: "${POCKET_IC_BIN:?set an explicit prepared PocketIC server}"
python3 run.py
for cohort in derive-scale-1 derive-scale; do
    output="$PWD/replay-$cohort"
    mkdir "$output"
    for variant in baseline automatic outlined; do
        cp "$variant-$cohort.wasm" "$output/$variant-wire.wasm"
    done
    cargo run --locked --offline --manifest-path source/Cargo.toml -p ic-wire-benchmarks --example codec-instructions --features "wire,candid,ic,$cohort" -- "$output"
done
