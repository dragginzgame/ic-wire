#!/usr/bin/env bash
set -euo pipefail
r=${WIRE_STRICT_ROOT:-/tmp/wire-strict-0614}
export CARGO_TARGET_DIR=${CARGO_TARGET_DIR:-/tmp/wire-hotspots-0613/build} CARGO_NET_OFFLINE=true
for v in before strict; do
 cd "$r/$v"
 find crates vendor -name '*.rs' -exec touch {} +
 cargo run --locked --offline -p ic-wire --example strict-probe -- "$v" > "$r/$v-acceptance.log" 2>&1
 for profile in evaluation benchmark-speed; do
  cargo build --locked --offline --profile "$profile" -p ic-wire-benchmarks --example codec-wasm --target wasm32-unknown-unknown --features wire,derive-scale > "$r/$v-records-$profile.log" 2>&1
  cp "$CARGO_TARGET_DIR/wasm32-unknown-unknown/$profile/examples/codec_wasm.wasm" "$r/$v-records-$profile.wasm"
 done
done
