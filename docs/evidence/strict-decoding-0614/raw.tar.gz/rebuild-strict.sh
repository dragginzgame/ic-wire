#!/usr/bin/env bash
set -euo pipefail
r=${WIRE_STRICT_ROOT:-/tmp/wire-strict-0614}
cd "$r/strict"
export CARGO_TARGET_DIR=${CARGO_TARGET_DIR:-/tmp/wire-hotspots-0613/build} CARGO_NET_OFFLINE=true
find crates vendor -name '*.rs' -exec touch {} +
for profile in evaluation benchmark-speed; do
 cargo build --locked --offline --profile "$profile" -p ic-wire-benchmarks --example codec-wasm --target wasm32-unknown-unknown --features wire,hotspots > "$r/strict-$profile.log" 2>&1
 cp "$CARGO_TARGET_DIR/wasm32-unknown-unknown/$profile/examples/codec_wasm.wasm" "$r/ic-strict/$profile-wire.wasm"
done
