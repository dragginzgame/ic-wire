#!/usr/bin/env bash
set -euo pipefail
archive="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
r="${1:?usage: replay.sh FRESH_ABSOLUTE_DIRECTORY}"
: "${POCKET_IC_BIN:?prepare PocketIC 16.1.0 explicitly}"
case "$r" in /*) ;; *) exit 1;; esac
mkdir "$r"
for v in before strict; do
 mkdir "$r/$v"
 tar -xf "$archive/$v-source.tar" -C "$r/$v"
done
export WIRE_STRICT_ROOT="$r" CARGO_TARGET_DIR="$r/target"
bash "$archive/build.sh"
# The frozen strict source already includes the char fix used in retained runs.
for v in before strict; do "$r/driver" "$r/ic-$v" > "$r/ic-$v.log" 2>&1; done
bash "$archive/qualify.sh"
node "$archive/analyze.mjs"
