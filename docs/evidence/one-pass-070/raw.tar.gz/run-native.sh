#!/usr/bin/env bash
set -euo pipefail
r=${WIRE_CUT_ROOT:-/tmp/wire-cut-070}
export GIT_DIR="${WIRE_SOURCE_REPO:?}/.git" GIT_WORK_TREE="$WIRE_SOURCE_REPO" GIT_OPTIONAL_LOCKS=0
for run in 1 2; do
 if [ "$run" = 1 ]; then order='before after'; else order='after before'; fi
 for v in $order; do
  for p in evaluation benchmark-speed; do
   "$r/$v-$p-native" "$r/native-$v-$p-$run" "$p" 11 2 > "$r/native-$v-$p-$run.log" 2>&1
  done
 done
done
