#!/usr/bin/env bash
set -euo pipefail
source_dir=$(cd -- "$(dirname -- "$0")" && pwd)
export WIRE_CUT_ROOT=${1:?absolute fresh output directory}
export WIRE_SOURCE_REPO=${2:?absolute original Git checkout}
: "${POCKET_IC_BIN:?prepared PocketIC 16.1.0 binary}"
mkdir "$WIRE_CUT_ROOT"
export CARGO_TARGET_DIR="$WIRE_CUT_ROOT/target" CARGO_NET_OFFLINE=true
export GIT_DIR="$WIRE_SOURCE_REPO/.git" GIT_WORK_TREE="$WIRE_SOURCE_REPO" GIT_OPTIONAL_LOCKS=0
for variant in before after; do
 tar -xf "$source_dir/$variant.tar" -C "$WIRE_CUT_ROOT"
done
bash "$source_dir/build.sh"
for variant in before after; do
 "$WIRE_CUT_ROOT/driver" "$WIRE_CUT_ROOT/ic-$variant" > "$WIRE_CUT_ROOT/ic-$variant.log" 2>&1
done
bash "$source_dir/run-native.sh"
node "$source_dir/analyze.mjs" > "$WIRE_CUT_ROOT/screen.txt"
node "$source_dir/native-analysis.mjs" > "$WIRE_CUT_ROOT/native-screen.txt"
