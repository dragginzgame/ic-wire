import fs from 'node:fs';
const root=process.env.WIRE_CUT_ROOT??'/tmp/wire-cut-070';
const variants=['before','after'];
function size(path) { const b=fs.readFileSync(path);let p=8,code=0;function leb(){let n=0,s=0,v;do{v=b[p++];n+=(v&127)*2**s;s+=7;}while(v&128);return n;}while(p<b.length){const id=b[p++],n=leb();if(id===10)code=n;p+=n;}return{total:b.length,code}; }
const sizes={};for(const v of variants){sizes[v]={};for(const p of ['evaluation','benchmark-speed']) {const path=`${root}/ic-${v}/${p}-wire.wasm`;if(fs.existsSync(path))sizes[v][p]=size(path);}}
fs.writeFileSync(`${root}/wasm.json`,JSON.stringify(sizes,null,2)+'\n');console.log(sizes);
const rows=v=>fs.readFileSync(`${root}/ic-${v}/instructions/samples.jsonl`,'utf8').trim().split('\n').map(JSON.parse);
const key=r=>[r.profile,r.case,r.codec,r.operation].join(',');
if(!fs.existsSync(`${root}/ic-before/instructions/samples.jsonl`))process.exit();
const baseline=new Map(rows('before').map(r=>[key(r),r]));let out='variant,profile,case,codec,operation,bytes,before,after,percent\n';
for(const v of variants.slice(1)){
 if(!fs.existsSync(`${root}/ic-${v}/instructions/samples.jsonl`))continue;
 const results=rows(v);let changes=[];
 for(const r of results){const b=baseline.get(key(r));if(!b)throw Error('key');for(const f of ['input_sha256','payload_sha256','encoded_bytes','repetitions'])if(r[f]!==b[f])throw Error(f);
 for(const row of [b,r])if(row.samples_instructions.length!==3||new Set(row.samples_instructions).size!==1)throw Error('samples');
 if(r.codec==='candid'&&r.median_instructions_per_op!==b.median_instructions_per_op)throw Error('candid');
 const p=100*(r.median_instructions_per_op/b.median_instructions_per_op-1);
 out+=`${v},${key(r)},${r.encoded_bytes},${b.median_instructions_per_op},${r.median_instructions_per_op},${p}\n`;
 if(r.codec.startsWith('wire')&&r.operation.startsWith('decode')&&['blob-1048576','blob-0','blob-64','mixed-blob-1048576','mixed-blob-64'].includes(r.case))console.log(v,r.profile,r.case,b.median_instructions_per_op,r.median_instructions_per_op,p.toFixed(2));
 if(r.codec.startsWith('wire'))changes.push({case:r.case,profile:r.profile,op:r.operation,p});
 }
 console.log(v,'rows',results.length,'worst',changes.sort((a,b)=>b.p-a.p).slice(0,3));
}
fs.writeFileSync(`${root}/comparison.csv`,out);
for(const v of variants){sizes[v].records={};for(const p of ['evaluation','benchmark-speed'])sizes[v].records[p]=size(`${root}/${v}-records-${p}.wasm`);}
fs.writeFileSync(`${root}/wasm.json`,JSON.stringify(sizes,null,2)+'\n');
console.log('records',JSON.stringify(Object.fromEntries(variants.map(v=>[v,sizes[v].records]))));
