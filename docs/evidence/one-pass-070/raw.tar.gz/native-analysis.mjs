import fs from 'node:fs';
const root=process.env.WIRE_CUT_ROOT??'/tmp/wire-cut-070';
const profiles=['evaluation','benchmark-speed'];
const key=r=>[r.case,r.codec,r.operation].join(',');
const read=(v,p,n)=>fs.readFileSync(`${root}/native-${v}-${p}-${n}/samples.jsonl`,'utf8').trim().split('\n').map(JSON.parse);
let output='profile,case,codec,operation,before_run1_ns,before_run2_ns,after_run1_ns,after_run2_ns,midpoint_percent\n';let summary=[];
for(const p of profiles){
 const maps={};for(const v of ['before','after'])maps[v]=[1,2].map(n=>new Map(read(v,p,n).map(r=>[key(r),r])));
 if(maps.before[0].size!==maps.after[1].size)throw Error('row count');
 for(const [k,b] of maps.before[0]){
  const rows=[maps.before[0].get(k),maps.before[1].get(k),maps.after[0].get(k),maps.after[1].get(k)];
  for(const r of rows){if(!r||r.input_sha256!==b.input_sha256||r.encoded_sha256!==b.encoded_sha256||r.encoded_bytes!==b.encoded_bytes||r.measurement.samples_ns_per_op.length!==11)throw Error('identity/samples');}
  const ns=rows.map(r=>r.measurement.median_ns),pct=100*((ns[2]+ns[3])/(ns[0]+ns[1])-1);
  output+=`${p},${k},${ns.join(',')},${pct}\n`;
  if(b.codec.startsWith('wire'))summary.push({profile:p,case:b.case,operation:b.operation,ns,percent:pct});
 }
}
fs.writeFileSync(`${root}/native.csv`,output);
console.log('selected',summary.filter(r=>['blob-0','blob-64','blob-1048576','mixed-blob-1048576','i16-wide-16384'].includes(r.case)&&r.operation.startsWith('decode')));
console.log('worst regressions',summary.sort((a,b)=>b.percent-a.percent).slice(0,8));
