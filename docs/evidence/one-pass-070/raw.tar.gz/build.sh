#!/usr/bin/env bash
set -euo pipefail
r=${WIRE_CUT_ROOT:-/tmp/wire-cut-070}
export CARGO_TARGET_DIR=${CARGO_TARGET_DIR:-/tmp/wire-hotspots-0613/build} CARGO_NET_OFFLINE=true
for variant in before after; do
 cd "$r/$variant"
 find crates -name '*.rs' -exec touch {} +
 mkdir "$r/ic-$variant"
 for profile in evaluation benchmark-speed; do
  for cohort in hotspots derive-scale; do
   cargo build --locked --offline --profile "$profile" -p ic-wire-benchmarks --example codec-wasm --target wasm32-unknown-unknown --features "wire,$cohort" > "$r/$variant-$cohort-$profile.log" 2>&1
   artifact="$CARGO_TARGET_DIR/wasm32-unknown-unknown/$profile/examples/codec_wasm.wasm"
   if [ "$cohort" = hotspots ]; then cp "$artifact" "$r/ic-$variant/$profile-wire.wasm"; else cp "$artifact" "$r/$variant-records-$profile.wasm"; fi
  done
  if [ "$variant" = before ]; then
   cargo build --locked --offline --profile "$profile" -p ic-wire-benchmarks --example codec-wasm --target wasm32-unknown-unknown --features candid,hotspots > "$r/candid-$profile.log" 2>&1
   cp "$CARGO_TARGET_DIR/wasm32-unknown-unknown/$profile/examples/codec_wasm.wasm" "$r/$profile-candid.wasm"
  fi
  cp "$r/$profile-candid.wasm" "$r/ic-$variant/$profile-candid.wasm"
  cargo bench --locked --offline --no-run --profile "$profile" -p ic-wire-benchmarks --bench suite --features wire,candid,hotspots --message-format=json > "$r/$variant-$profile-native.jsonl" 2> "$r/$variant-$profile-native.log"
  node --input-type=module - "$r/$variant-$profile-native.jsonl" "$r/$variant-$profile-native" <<'JS'
import fs from 'node:fs';
for(const line of fs.readFileSync(process.argv[2],'utf8').trim().split('\n')){const a=JSON.parse(line);if(a.reason==='compiler-artifact'&&a.executable&&a.target.name==='suite'){fs.copyFileSync(a.executable,process.argv[3]);fs.chmodSync(process.argv[3],0o755);}}
JS
 done
 if [ "$variant" = before ]; then
  cargo build --locked --offline -p ic-wire-benchmarks --example codec-instructions --features wire,candid,ic,hotspots > "$r/driver.log" 2>&1
  cp "$CARGO_TARGET_DIR/debug/examples/codec-instructions" "$r/driver"
 fi
done
