#!/usr/bin/env bash
set -euo pipefail
r=/tmp/wire-hotspots-0613
cd "$r/before"
export CARGO_TARGET_DIR="$r/build" CARGO_NET_OFFLINE=true RUSTUP_AUTO_INSTALL=0
find crates -name '*.rs' -exec touch {} +
for profile in evaluation benchmark-speed; do
 cargo build --locked --offline --profile "$profile" -p ic-wire-benchmarks --example codec-wasm --target wasm32-unknown-unknown --features candid,hotspots > "$r/candid-$profile-build.log" 2>&1
 cp "$CARGO_TARGET_DIR/wasm32-unknown-unknown/$profile/examples/codec_wasm.wasm" "$r/candid-$profile.wasm"
 python3 "$r/size.py" candid "$profile" "$r/candid-$profile.wasm" >> "$r/screen.csv"
done
cargo build --locked --offline -p ic-wire-benchmarks --example codec-instructions --features wire,candid,ic,hotspots > "$r/driver-build.log" 2>&1
cp "$CARGO_TARGET_DIR/debug/examples/codec-instructions" "$r/driver"
for variant in before cursor signed varint inline; do
 mkdir "$r/ic-$variant"
 for profile in evaluation benchmark-speed; do
  cp "$r/$variant-$profile.wasm" "$r/ic-$variant/$profile-wire.wasm"
  cp "$r/candid-$profile.wasm" "$r/ic-$variant/$profile-candid.wasm"
 done
done
