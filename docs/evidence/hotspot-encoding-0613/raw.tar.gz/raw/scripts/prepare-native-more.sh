#!/usr/bin/env bash
set -euo pipefail
r=/tmp/wire-hotspots-0613
export CARGO_TARGET_DIR="$r/build" CARGO_NET_OFFLINE=true RUSTUP_AUTO_INSTALL=0
for variant in i16 varint-inline; do
 cd "$r/$variant"
 find crates -name '*.rs' -exec touch {} +
 for profile in evaluation benchmark-speed; do
  cargo bench --locked --offline --no-run --profile "$profile" -p ic-wire-benchmarks --bench suite --features wire,candid,hotspots --message-format=json > "$r/$variant-$profile-native-build.jsonl" 2> "$r/$variant-$profile-native-build.log"
  python3 - "$r/$variant-$profile-native-build.jsonl" "$r/$variant-$profile-native" <<'PY'
import sys,json,shutil
for line in open(sys.argv[1]):
 a=json.loads(line)
 if a.get('reason')=='compiler-artifact' and a.get('executable') and a['target']['name']=='suite':shutil.copyfile(a['executable'],sys.argv[2]);shutil.copymode(a['executable'],sys.argv[2])
PY
 done
done
