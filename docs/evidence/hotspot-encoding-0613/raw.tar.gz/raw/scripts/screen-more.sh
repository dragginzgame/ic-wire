#!/usr/bin/env bash
set -euo pipefail
r=/tmp/wire-hotspots-0613
export CARGO_TARGET_DIR="$r/build" CARGO_NET_OFFLINE=true RUSTUP_AUTO_INSTALL=0
for variant in short short-signed varint-inline i16; do
 cd "$r/$variant"
 find crates -name '*.rs' -exec touch {} +
 mkdir "$r/ic-$variant"
 for profile in evaluation benchmark-speed; do
  cargo build --locked --offline --profile "$profile" -p ic-wire-benchmarks --example codec-wasm --target wasm32-unknown-unknown --features wire,hotspots > "$r/$variant-$profile-build.log" 2>&1
  artifact="$CARGO_TARGET_DIR/wasm32-unknown-unknown/$profile/examples/codec_wasm.wasm"
  cp "$artifact" "$r/$variant-$profile.wasm"
  cp "$artifact" "$r/ic-$variant/$profile-wire.wasm"
  cp "$r/candid-$profile.wasm" "$r/ic-$variant/$profile-candid.wasm"
  python3 "$r/size.py" "$variant" "$profile" "$artifact" >> "$r/screen.csv"
 done
done
