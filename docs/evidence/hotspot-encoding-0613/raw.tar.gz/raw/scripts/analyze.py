import csv,json,pathlib,hashlib,statistics
r=pathlib.Path(__file__).resolve().parent
out=r/'analysis';out.mkdir(exist_ok=True)
variants=['before','cursor','signed','varint','inline','short','short-signed','varint-inline','i16','i16-varint']
def rows(p):return list(csv.DictReader(p.open()))
def write(name,items):
 if not items:return
 with (out/name).open('w')as f:
  w=csv.DictWriter(f,fieldnames=list(items[0]));w.writeheader();w.writerows(items)
def ic(folder):
 raw=[json.loads(line) for line in (folder/'instructions/samples.jsonl').read_text().splitlines()]
 for a in raw:
  assert len(a['samples_instructions'])==3 and len(set(a['samples_instructions']))==1,a
 return {(a['profile'],a['case'],a['codec'],a['operation']):a for a in raw}
checks={};all_ic=[];comparisons=[]
base=ic(r/'ic-before')
for v in variants:
 d=ic(r/f'ic-{v}');assert d.keys()==base.keys()
 ident=json.loads((r/f'ic-{v}/instructions/identity.json').read_text())
 for a in ident['artifacts']:
  assert a['sha256']==hashlib.sha256((r/f'ic-{v}'/f"{a['profile']}-{a['codec']}.wasm").read_bytes()).hexdigest()
 for k,a in d.items():
  b=base[k]
  assert (a['input_sha256'],a['payload_sha256'],a['encoded_bytes'])==(b['input_sha256'],b['payload_sha256'],b['encoded_bytes'])
  if k[2]=='candid':assert a['samples_instructions']==b['samples_instructions']
  all_ic.append(dict(variant=v,profile=k[0],case=k[1],codec=k[2],operation=k[3],encoded_bytes=a['encoded_bytes'],instructions=a['median_instructions_per_op']))
  if k[2]=='wire-native':
   c=base[(k[0],k[1],'candid',k[3])] if k[3]!='encode-reuse' else None
   comparisons.append(dict(variant=v,profile=k[0],case=k[1],operation=k[3],before=b['median_instructions_per_op'],after=a['median_instructions_per_op'],change_percent=100*(a['median_instructions_per_op']/b['median_instructions_per_op']-1),candid=c['median_instructions_per_op']if c else '',wire_over_candid=a['median_instructions_per_op']/c['median_instructions_per_op']if c else '',encoded_bytes=a['encoded_bytes']))
checks['hotspots']={'variants':len(variants),'cases_per_variant':50,'rows':len(all_ic),'samples_per_row':3,'identical_frames_and_inputs':True,'identical_repeated_counters':True}
write('hotspots-instructions.csv',all_ic);write('hotspots-changes.csv',comparisons)
sizes=rows(r/'screen.csv')+rows(r/'scale.csv')+rows(r/'inline-screen.csv')
for a in sizes:
 p=r/(a['variant'].replace('/','-')+'-'+a['profile']+'.wasm')
 wasm=p.read_bytes();assert len(wasm)==int(a['total']) and hashlib.sha256(wasm).hexdigest()==a['sha256']
 position=8;code=0
 while position<len(wasm):
  section=wasm[position];position+=1;length=0;shift=0
  while True:
   byte=wasm[position];position+=1;length|=(byte&127)<<shift
   if byte<128:break
   shift+=7
  if section==10:code=length
  position+=length
 assert code==int(a['code'])
checks['wasm']={'artifacts':len(sizes),'sizes_and_hashes_validated':True}
for profile in ['evaluation','benchmark-speed']:
 for cohort in ['standard','hotspots']:
  original=r/('i16-varint-'+('standard-'if cohort=='standard'else'')+profile+'.wasm')
  assert original.read_bytes()==(r/f'i16-u16-inline-{cohort}-{profile}.wasm').read_bytes()
write('wasm.csv',sizes)
if (r/'standard-i16-varint/instructions/identity.json').exists():
 b=ic(r/'standard-before');d=ic(r/'standard-i16-varint');assert b.keys()==d.keys();standard=[]
 for k,a in d.items():
  before=b[k];assert (a['input_sha256'],a['payload_sha256'],a['encoded_bytes'])==(before['input_sha256'],before['payload_sha256'],before['encoded_bytes'])
  if k[2]=='candid':assert a['samples_instructions']==before['samples_instructions']
  if k[2].startswith('wire-'):
   c=b.get((k[0],k[1],'candid',k[3]))
   standard.append(dict(profile=k[0],case=k[1],codec=k[2],operation=k[3],before=before['median_instructions_per_op'],after=a['median_instructions_per_op'],change_percent=100*(a['median_instructions_per_op']/before['median_instructions_per_op']-1),candid=c['median_instructions_per_op']if c else '',wire_over_candid=a['median_instructions_per_op']/c['median_instructions_per_op']if c else '',encoded_bytes=a['encoded_bytes']))
 write('standard-changes.csv',standard)
 checks['standard']={'cases':298,'rows_per_variant':len(d),'identical_frames_and_inputs':True,'identical_repeated_counters':True}
if (r/'native-i16-varint-benchmark-speed-2/identity.json').exists():
 native={};native_raw=[]
 for v in ['before','i16-varint']:
  for profile in ['evaluation','benchmark-speed']:
   for run in [1,2]:
    folder=r/f'native-{v}-{profile}-{run}'
    ident=json.loads((folder/'identity.json').read_text());assert ident['samples']==11 and ident['minimum_batch_ms']==2
    for line in (folder/'samples.jsonl').read_text().splitlines():
     a=json.loads(line);assert len(a['measurement']['samples_ns_per_op'])==11
     key=(profile,a['case'],a['codec'],a['operation']);old=base[key]
     assert a['input_sha256']==old['input_sha256'] and a['encoded_sha256']==old['payload_sha256']
     native.setdefault((v,*key),[]).append(a['measurement']['median_ns']);native_raw.append(dict(variant=v,profile=profile,run=run,**a))
 n=[]
 for key in {k[1:] for k in native}:
  before=native['before',*key];after=native['i16-varint',*key];bv=statistics.median(before);av=statistics.median(after)
  n.append(dict(profile=key[0],case=key[1],codec=key[2],operation=key[3],before_ns=bv,after_ns=av,change_percent=100*(av/bv-1),before_run_medians=before,after_run_medians=after))
 write('native-changes.csv',sorted(n,key=lambda a:(a['profile'],a['case'],a['codec'],a['operation'])))
 checks['native']={'runs':2,'samples':11,'minimum_batch_ms':2,'identical_frames_and_inputs':True,'rows':len(native_raw)}
(out/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps(checks,indent=2))
