#!/usr/bin/env bash
set -euo pipefail
r=/tmp/wire-hotspots-0613
export CARGO_TARGET_DIR="$r/build" CARGO_NET_OFFLINE=true RUSTUP_AUTO_INSTALL=0
printf 'variant,profile,total,code,sha256\n' > "$r/scale.csv"
for variant in before i16-varint; do
 cd "$r/$variant"
 find crates -name '*.rs' -exec touch {} +
 for cohort in records-1 records-100 bulk-100 ordinary-bulk-100 standard; do
  case "$cohort" in
   records-1) extra=,derive-scale-1;;
   records-100) extra=,derive-scale;;
   bulk-100) extra=,bulk-scale;;
   ordinary-bulk-100) extra=,bulk-scale,bulk-baseline;;
   standard) extra=;;
  esac
  for profile in evaluation benchmark-speed; do
   cargo build --locked --offline --profile "$profile" -p ic-wire-benchmarks --example codec-wasm --target wasm32-unknown-unknown --features "wire$extra" > "$r/$variant-$cohort-$profile-build.log" 2>&1
   artifact="$CARGO_TARGET_DIR/wasm32-unknown-unknown/$profile/examples/codec_wasm.wasm"
   cp "$artifact" "$r/$variant-$cohort-$profile.wasm"
   python3 "$r/size.py" "$variant/$cohort" "$profile" "$artifact" >> "$r/scale.csv"
  done
 done
done
cd "$r/before"
find crates -name '*.rs' -exec touch {} +
for profile in evaluation benchmark-speed; do
 cargo build --locked --offline --profile "$profile" -p ic-wire-benchmarks --example codec-wasm --target wasm32-unknown-unknown --features candid > "$r/candid-standard-$profile-build.log" 2>&1
 cp "$CARGO_TARGET_DIR/wasm32-unknown-unknown/$profile/examples/codec_wasm.wasm" "$r/candid-standard-$profile.wasm"
 python3 "$r/size.py" candid/standard "$profile" "$r/candid-standard-$profile.wasm" >> "$r/scale.csv"
done
cargo build --locked --offline -p ic-wire-benchmarks --example codec-instructions --features wire,candid,ic > "$r/standard-driver-build.log" 2>&1
cp "$CARGO_TARGET_DIR/debug/examples/codec-instructions" "$r/standard-driver"
for variant in before i16-varint; do
 mkdir "$r/standard-$variant"
 for profile in evaluation benchmark-speed; do
  cp "$r/$variant-standard-$profile.wasm" "$r/standard-$variant/$profile-wire.wasm"
  cp "$r/candid-standard-$profile.wasm" "$r/standard-$variant/$profile-candid.wasm"
 done
done
