#!/usr/bin/env bash
set -euo pipefail
r=/tmp/wire-hotspots-0613
export CARGO_TARGET_DIR="$r/build" CARGO_NET_OFFLINE=true RUSTUP_AUTO_INSTALL=0
printf "variant,profile,total,code,sha256\n" > "$r/inline-screen.csv"
cd "$r/i16-u16-inline"
find crates -name '*.rs' -exec touch {} +
mkdir "$r/standard-i16-u16-inline" "$r/ic-i16-u16-inline"
for cohort in standard hotspots; do
 if [ "$cohort" = standard ]; then extra=; dest=standard; else extra=,hotspots; dest=ic; fi
 for profile in evaluation benchmark-speed; do
  cargo build --locked --offline --profile "$profile" -p ic-wire-benchmarks --example codec-wasm --target wasm32-unknown-unknown --features "wire$extra" > "$r/i16-u16-inline-$cohort-$profile-build.log" 2>&1
  artifact="$CARGO_TARGET_DIR/wasm32-unknown-unknown/$profile/examples/codec_wasm.wasm"
  cp "$artifact" "$r/i16-u16-inline-$cohort-$profile.wasm"
  cp "$artifact" "$r/$dest-i16-u16-inline/$profile-wire.wasm"
  cp "$r/$dest-before/$profile-candid.wasm" "$r/$dest-i16-u16-inline/$profile-candid.wasm"
  python3 "$r/size.py" "i16-u16-inline/$cohort" "$profile" "$artifact" >> "$r/inline-screen.csv"
 done
done
