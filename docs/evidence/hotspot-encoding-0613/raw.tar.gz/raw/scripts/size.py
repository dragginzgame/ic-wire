import sys,hashlib
b=open(sys.argv[3],'rb').read();p=8;code=0
while p<len(b):
 k=b[p];p+=1;n=0;s=0
 while True:
  v=b[p];p+=1;n|=(v&127)<<s
  if v<128:break
  s+=7
 if k==10:code=n
 p+=n
print(','.join([sys.argv[1],sys.argv[2],str(len(b)),str(code),hashlib.sha256(b).hexdigest()]))
