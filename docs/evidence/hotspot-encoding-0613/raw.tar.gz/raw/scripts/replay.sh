#!/usr/bin/env bash
# Run from an extracted raw/ archive; all writes go into a fresh scratch directory.
set -euo pipefail
archive="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
work="${1:?usage: replay.sh FRESH_ABSOLUTE_DIRECTORY ORIGINAL_REPOSITORY}"
repository="${2:?original repository supplies Git identity for the native runner}"
: "${POCKET_IC_BIN:?prepare PocketIC 16.1.0 explicitly}"
case "$work" in /*) ;; *) echo 'scratch directory must be absolute' >&2; exit 1;; esac
mkdir "$work"
variants='before cursor signed varint inline short short-signed varint-inline i16 i16-varint i16-u16-inline'
for variant in $variants; do
 cp -R "$archive/sources/before" "$work/$variant"
 if [ -d "$archive/sources/overlays/$variant" ]; then cp -R "$archive/sources/overlays/$variant/." "$work/$variant/"; fi
done
# Preserve the original scripts, but substitute their isolated scratch/Git roots.
python3 - "$archive" "$work" "$repository" <<'PY'
import pathlib,sys,shlex
archive,work,repo=map(pathlib.Path,sys.argv[1:])
for p in (archive/'scripts').iterdir():
 if p.name=='replay.sh':continue
 s=p.read_text().replace('r=/tmp/wire-hotspots-0613','r='+shlex.quote(str(work)))
 s=s.replace('GIT_DIR=/home/adam/projects/ic-wire/.git','GIT_DIR='+shlex.quote(str(repo/'.git')))
 s=s.replace('GIT_WORK_TREE=/home/adam/projects/ic-wire','GIT_WORK_TREE='+shlex.quote(str(repo)))
 (work/p.name).write_text(s)
PY
bash "$work/screen.sh"
bash "$work/prepare-ic.sh"
for variant in before cursor signed varint inline; do "$work/driver" "$work/ic-$variant" > "$work/ic-$variant.log" 2>&1; done
bash "$work/screen-more.sh"
for variant in short short-signed varint-inline i16; do "$work/driver" "$work/ic-$variant" > "$work/ic-$variant.log" 2>&1; done
bash "$work/screen-final.sh"
"$work/driver" "$work/ic-i16-varint" > "$work/ic-i16-varint.log" 2>&1
bash "$work/qualify.sh"
for variant in before i16-varint; do "$work/standard-driver" "$work/standard-$variant" > "$work/standard-$variant.log" 2>&1; done
bash "$work/prepare-native.sh"
bash "$work/prepare-native-more.sh"
bash "$work/prepare-native-final.sh"
bash "$work/screen-inline.sh"
# Only the two measured native variants run here; compilation has finished.
bash "$work/native.sh"
python3 "$work/analyze.py"
