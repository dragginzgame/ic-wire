#!/usr/bin/env bash
set -euo pipefail
r=/tmp/wire-hotspots-0613
export GIT_DIR=/home/adam/projects/ic-wire/.git GIT_WORK_TREE=/home/adam/projects/ic-wire GIT_OPTIONAL_LOCKS=0
for run in 1 2; do
 if [ "$run" = 1 ]; then order='before i16-varint'; else order='i16-varint before'; fi
 for variant in $order; do
  for profile in evaluation benchmark-speed; do
   "$r/$variant-$profile-native" "$r/native-$variant-$profile-$run" "$profile" 11 2 > "$r/native-$variant-$profile-$run.log" 2>&1
  done
 done
done
