#!/usr/bin/env bash
set -euo pipefail
r=${WIRE_COMPARE_ROOT:-/tmp/wire-compare-0613}
export CARGO_TARGET_DIR=${CARGO_TARGET_DIR:-/tmp/wire-hotspots-0613/build} CARGO_NET_OFFLINE=true
cd "$r/no-canonical"
find crates -name '*.rs' -exec touch {} +
mkdir "$r/ic-no-canonical"
for profile in evaluation benchmark-speed; do
 cargo build --locked --offline --profile "$profile" -p ic-wire-benchmarks --example codec-wasm --target wasm32-unknown-unknown --features wire,hotspots > "$r/no-canonical-$profile.log" 2>&1
 cp "$CARGO_TARGET_DIR/wasm32-unknown-unknown/$profile/examples/codec_wasm.wasm" "$r/ic-no-canonical/$profile-wire.wasm"
 cp "$r/$profile-candid.wasm" "$r/ic-no-canonical/$profile-candid.wasm"
done
