use strict; use warnings;
my $root=$ENV{WIRE_COMPARE_ROOT} // '/tmp/wire-compare-0613';
for my $v ('no-scan','array-eq','word64') {
 my $dir="$root/$v"; mkdir $dir or die $!;
 system('tar','-xf',"$root/source.tar",'-C',$dir)==0 or die;
 my $path="$dir/crates/ic-wire/src/contract/mod.rs";
 open my $in,'<',$path or die $!; local $/; my $s=<$in>; close $in;
 if ($v eq 'no-scan') {
  # Diagnostic only: preserve pointer/scalar/length work, omit bulk comparisons.
  $s =~ s/\} else if cfg!\(any\(target_arch = "wasm32", test\)\) && bytes.len\(\) >= 8 \{/} else if bytes.len() >= 8 { true } else if cfg!(any(target_arch = "wasm32", test)) \&\& bytes.len() >= 8 {/ or die;
 } else {
  my $a=index($s,'    left.iter().zip(right).fold(0_u128');
  my $b=index($s,'        && {',$a);
  die if $a<0 || $b<0;
  my $body;
  if ($v eq 'array-eq') { $body="    left.iter().zip(right).all(|(a, b)| a == b)\n"; }
  else {
   my $terms=join("\n", map { "            | (u64::from_ne_bytes(a[$_]) ^ u64::from_ne_bytes(b[$_]))" } 0..7);
   $body="    left.iter().zip(right).fold(0_u64, |difference, (a, b)| {\n        let (a, _) = a.as_chunks::<8>();\n        let (b, _) = b.as_chunks::<8>();\n        difference\n$terms\n    }) == 0\n";
  }
  substr($s,$a,$b-$a,$body);
 }
 open my $out,'>',$path or die $!; print $out $s;
}
{
 my $dir="$root/no-canonical"; mkdir $dir or die $!;
 system('tar','-xf',"$root/source.tar",'-C',$dir)==0 or die;
 my $path="$dir/crates/ic-wire/src/native/mod.rs";
 open my $in,'<',$path or die $!; local $/; my $s=<$in>; close $in;
 $s =~ s/    let budget = Budget::new\(limits\);\n    let equal = postcard::serialize_with_flavor\(.*?    if !equal \{\n        return Err\(Error::Noncanonical\);\n    \}\n/    \/\/ Diagnostic only: remove canonical validation, never ship this variant.\n/s or die;
 open my $out,'>',$path or die $!; print $out $s;
}
