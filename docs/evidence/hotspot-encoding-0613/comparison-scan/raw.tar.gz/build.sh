#!/usr/bin/env bash
set -euo pipefail
r=${WIRE_COMPARE_ROOT:-/tmp/wire-compare-0613}
export CARGO_TARGET_DIR=${CARGO_TARGET_DIR:-/tmp/wire-hotspots-0613/build} CARGO_NET_OFFLINE=true
for variant in before no-scan array-eq word64; do
 cd "$r/$variant"
 find crates -name '*.rs' -exec touch {} +
 mkdir "$r/ic-$variant"
 for profile in evaluation benchmark-speed; do
  cargo build --locked --offline --profile "$profile" -p ic-wire-benchmarks --example codec-wasm --target wasm32-unknown-unknown --features wire,hotspots > "$r/$variant-$profile.log" 2>&1
  cp "$CARGO_TARGET_DIR/wasm32-unknown-unknown/$profile/examples/codec_wasm.wasm" "$r/ic-$variant/$profile-wire.wasm"
  if [ "$variant" = before ]; then
   cargo build --locked --offline --profile "$profile" -p ic-wire-benchmarks --example codec-wasm --target wasm32-unknown-unknown --features candid,hotspots > "$r/candid-$profile.log" 2>&1
   cp "$CARGO_TARGET_DIR/wasm32-unknown-unknown/$profile/examples/codec_wasm.wasm" "$r/$profile-candid.wasm"
  fi
  cp "$r/$profile-candid.wasm" "$r/ic-$variant/$profile-candid.wasm"
 done
 if [ "$variant" = before ]; then
  cargo build --locked --offline -p ic-wire-benchmarks --example codec-instructions --features wire,candid,ic,hotspots > "$r/driver.log" 2>&1
  cp "$CARGO_TARGET_DIR/debug/examples/codec-instructions" "$r/driver"
 fi
done
