#!/usr/bin/env bash
set -euo pipefail
archive="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
r="${1:?usage: replay.sh FRESH_ABSOLUTE_DIRECTORY}"
: "${POCKET_IC_BIN:?prepare PocketIC 16.1.0 explicitly}"
case "$r" in /*) ;; *) exit 1;; esac
mkdir "$r"
cp "$archive/source.tar" "$r/source.tar"
mkdir "$r/before"
tar -xf "$r/source.tar" -C "$r/before"
export WIRE_COMPARE_ROOT="$r" CARGO_TARGET_DIR="$r/target"
perl "$archive/prepare.pl"
bash "$archive/build.sh"
bash "$archive/build-diagnostic.sh"
for variant in before no-scan no-canonical array-eq word64; do
 "$r/driver" "$r/ic-$variant" > "$r/ic-$variant.log" 2>&1
done
node "$archive/analyze.mjs"
