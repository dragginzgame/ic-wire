//! Ordinary-list hot spots, with empty/singleton and byte-oriented controls.
use super::*;

pub(super) fn cases_selected(selected: Option<usize>) -> Vec<Case> {
    let mut out = Vec::new();
    let mut index = 0;
    macro_rules! push {
        ($case:expr) => {{
            if selected.is_none_or(|s| s == index) {
                out.push($case);
            }
            index += 1;
        }};
    }
    for n in [0, 1, 128, 16384] {
        for distribution in ["small", "wide", "negative", "mixed"] {
            push!({
                let choices = [i16::MIN, -65, -1, 0, 64, i16::MAX];
                let values = (0..n)
                    .map(|i| match distribution {
                        "small" => (i % 64) as i16,
                        "wide" => i16::MAX,
                        "negative" => -1 - (i % 64) as i16,
                        _ => choices[i % choices.len()],
                    })
                    .collect::<Vec<_>>();
                case(&format!("i16-{distribution}-{n}"), values)
            });
        }
        macro_rules! wide {
            ($($ty:ty),*) => {$(push!(case(&format!("{}-wide-{n}", stringify!($ty)), vec![<$ty>::MAX; n]));)*};
        }
        wide!(u16, i32, u32, i64, u64, i8);
    }
    for n in [0, 1, 7, 8, 9, 63, 64, 65, 127, 128, 129, 191, 192, 193, 255, 256, 257, 4095, 4096, 4097, 1_048_576] {
        push!(case(&format!("generic-bytes-{n}"), data(n)));
        push!(case(&format!("blob-{n}"), Blob(data(n))));
    }
    assert!(selected.is_none_or(|s| s < index), "unknown hotspot case");
    out
}
