#!/usr/bin/env bash
# Run beside source.tar and prepare.pl, with an explicitly prepared PocketIC.
set -euo pipefail
archive="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
r="${1:?usage: replay.sh FRESH_ABSOLUTE_SCRATCH_DIRECTORY}"
: "${POCKET_IC_BIN:?prepare PocketIC 16.1.0 explicitly}"
case "$r" in /*) ;; *) exit 1;; esac
mkdir "$r"
cp "$archive/source.tar" "$r/source.tar"
mkdir "$r/before"
tar -xf "$r/source.tar" -C "$r/before"
WIRE_DECODE_ROOT="$r" perl "$archive/prepare.pl"
for variant in before block128; do
 cp -R "$r/$variant" "$r/$variant-boundary"
 cp "$archive/boundary-fixture.rs" "$r/$variant-boundary/crates/ic-wire-benchmarks/fixtures/hotspots/mod.rs"
done
export CARGO_TARGET_DIR="$r/target" CARGO_NET_OFFLINE=true
for cohort in screen boundary; do
 if [ "$cohort" = screen ]; then variants='before block128 block256'; base=before; else variants='before-boundary block128-boundary'; base=before-boundary; fi
 cd "$r/$base"
 find crates -name '*.rs' -exec touch {} +
 cargo build --locked --offline -p ic-wire-benchmarks --example codec-instructions --features wire,candid,ic,hotspots
 cp "$CARGO_TARGET_DIR/debug/examples/codec-instructions" "$r/driver-$cohort"
 for profile in evaluation benchmark-speed; do
  cargo build --locked --offline --profile "$profile" -p ic-wire-benchmarks --example codec-wasm --target wasm32-unknown-unknown --features candid,hotspots
  cp "$CARGO_TARGET_DIR/wasm32-unknown-unknown/$profile/examples/codec_wasm.wasm" "$r/candid-$cohort-$profile.wasm"
 done
 for variant in $variants; do
  cd "$r/$variant"
  find crates -name '*.rs' -exec touch {} +
  mkdir "$r/ic-$variant"
  for profile in evaluation benchmark-speed; do
   cargo build --locked --offline --profile "$profile" -p ic-wire-benchmarks --example codec-wasm --target wasm32-unknown-unknown --features wire,hotspots
   cp "$CARGO_TARGET_DIR/wasm32-unknown-unknown/$profile/examples/codec_wasm.wasm" "$r/ic-$variant/$profile-wire.wasm"
   cp "$r/candid-$cohort-$profile.wasm" "$r/ic-$variant/$profile-candid.wasm"
  done
  "$r/driver-$cohort" "$r/ic-$variant"
 done
done
for helper in analyze.mjs boundary-analysis.mjs verify.mjs; do
 WIRE_DECODE_ROOT="$r" node "$archive/$helper"
done
