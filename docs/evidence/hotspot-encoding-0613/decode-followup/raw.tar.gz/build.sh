#!/usr/bin/env bash
set -euo pipefail
r=/tmp/wire-decode-0613
export CARGO_TARGET_DIR=/tmp/wire-hotspots-0613/build CARGO_NET_OFFLINE=true
for variant in before block128 block256; do
 cd "$r/$variant"
 find crates -name '*.rs' -exec touch {} +
 mkdir "$r/ic-$variant"
 for profile in evaluation benchmark-speed; do
  cargo build --locked --offline --profile "$profile" -p ic-wire-benchmarks --example codec-wasm --target wasm32-unknown-unknown --features wire,hotspots > "$r/$variant-$profile.log" 2>&1
  cp "$CARGO_TARGET_DIR/wasm32-unknown-unknown/$profile/examples/codec_wasm.wasm" "$r/ic-$variant/$profile-wire.wasm"
  cp "/tmp/wire-hotspots-0613/candid-$profile.wasm" "$r/ic-$variant/$profile-candid.wasm"
 done
done
