import fs from 'node:fs';
const root=process.env.WIRE_DECODE_ROOT ?? '/tmp/wire-decode-0613';
function size(path) {
 const b=fs.readFileSync(path); let p=8, code=0;
 function leb(){let n=0,s=0,v;do {v=b[p++];n+=(v&127)*2**s;s+=7;}while(v&128);return n;}
 while(p<b.length){const id=b[p++],n=leb();if(id===10)code=n;p+=n;}
 return {total:b.length,code};
}
function rows(v){return fs.readFileSync(`${root}/ic-${v}/instructions/summary.csv`,'utf8').trim().split('\n').slice(1).map(l=>l.split(','));}
const sizes={};
for(const v of ['before','block128','block256']) {
 sizes[v]={};for(const p of ['evaluation','benchmark-speed'])sizes[v][p]=size(`${root}/ic-${v}/${p}-wire.wasm`);
}
console.log(JSON.stringify(sizes,null,2));fs.writeFileSync(`${root}/wasm.json`,JSON.stringify(sizes,null,2)+'\n');
if(fs.existsSync(`${root}/ic-block256/instructions/summary.csv`)) {
 const base=new Map(rows('before').map(r=>[r.slice(0,4).join(','),r]));
 let out='variant,profile,case,codec,operation,bytes,before,after,percent\n';
 for(const v of ['block128','block256'])for(const r of rows(v)) {
  const b=base.get(r.slice(0,4).join(','));if(!b||b[4]!==r[4])throw Error('identity');
  const pct=100*(+r[5]/+b[5]-1);out+=`${v},${r.slice(0,5).join(',')},${b[5]},${r[5]},${pct}\n`;
  if(r[1].startsWith('blob-') && r[3].startsWith('decode'))console.log(v,...r,'delta',pct.toFixed(2));
 }
 fs.writeFileSync(`${root}/comparison.csv`,out);
}
