use strict; use warnings;
my $root=$ENV{WIRE_DECODE_ROOT} // '/tmp/wire-decode-0613';
for my $width (128,256) {
 my $dir="$root/block$width";
 mkdir $dir or die $!;
 system('tar','-xf',"$root/source.tar",'-C',$dir)==0 or die;
 my $path="$dir/crates/ic-wire/src/contract/mod.rs";
 open my $in,'<',$path or die $!; local $/; my $s=<$in>; close $in;
 # Only the out-of-line bulk loop changes. Its existing 64-byte entry threshold remains.
 my $start=index($s,'fn equal_bulk('); my $end=index($s,'pub(crate) fn header',$start);
 my $fn=substr($s,$start,$end-$start);
 $fn =~ s/as_chunks::<64>/as_chunks::<$width>/g;
 my $terms=join("\n", map { "            | (u128::from_ne_bytes(a[$_]) ^ u128::from_ne_bytes(b[$_]))" } 0..($width/16-1));
 $fn =~ s/        difference\n.*?\n    \}\)/        difference\n$terms\n    })/s;
 substr($s,$start,$end-$start,$fn);
 open my $out,'>',$path or die $!; print $out $s;
}
