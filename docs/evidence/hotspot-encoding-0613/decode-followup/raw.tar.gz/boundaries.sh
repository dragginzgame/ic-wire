#!/usr/bin/env bash
set -euo pipefail
r=/tmp/wire-decode-0613
export CARGO_TARGET_DIR=/tmp/wire-hotspots-0613/build CARGO_NET_OFFLINE=true
for variant in before block128; do
 cp -R "$r/$variant" "$r/$variant-boundary"
 cd "$r/$variant-boundary"
 perl -0pi -e 's/\[0, 1, 128, 4096, 1_048_576\]/[0, 1, 7, 8, 9, 63, 64, 65, 127, 128, 129, 191, 192, 193, 255, 256, 257, 4095, 4096, 4097, 1_048_576]/' crates/ic-wire-benchmarks/fixtures/hotspots/mod.rs
 find crates -name '*.rs' -exec touch {} +
 mkdir "$r/ic-$variant-boundary"
 for profile in evaluation benchmark-speed; do
  cargo build --locked --offline --profile "$profile" -p ic-wire-benchmarks --example codec-wasm --target wasm32-unknown-unknown --features wire,hotspots > "$r/$variant-boundary-$profile.log" 2>&1
  cp "$CARGO_TARGET_DIR/wasm32-unknown-unknown/$profile/examples/codec_wasm.wasm" "$r/ic-$variant-boundary/$profile-wire.wasm"
  if [ "$variant" = before ]; then
   cargo build --locked --offline --profile "$profile" -p ic-wire-benchmarks --example codec-wasm --target wasm32-unknown-unknown --features candid,hotspots > "$r/candid-boundary-$profile.log" 2>&1
   cp "$CARGO_TARGET_DIR/wasm32-unknown-unknown/$profile/examples/codec_wasm.wasm" "$r/$profile-boundary-candid.wasm"
  fi
  cp "$r/$profile-boundary-candid.wasm" "$r/ic-$variant-boundary/$profile-candid.wasm"
 done
 if [ "$variant" = before ]; then
  cargo build --locked --offline -p ic-wire-benchmarks --example codec-instructions --features wire,candid,ic,hotspots > "$r/boundary-driver.log" 2>&1
  cp "$CARGO_TARGET_DIR/debug/examples/codec-instructions" "$r/boundary-driver"
 fi
done
