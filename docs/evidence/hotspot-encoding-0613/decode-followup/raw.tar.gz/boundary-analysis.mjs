import fs from 'node:fs';
const root=process.env.WIRE_DECODE_ROOT ?? '/tmp/wire-decode-0613';
const read=v=>fs.readFileSync(`${root}/ic-${v}-boundary/instructions/summary.csv`,'utf8').trim().split('\n').slice(1).map(l=>l.split(','));
const before=new Map(read('before').map(r=>[r.slice(0,4).join(','),r]));
let out='profile,case,codec,operation,bytes,before,after,percent\n';
for(const r of read('block128')) {
 const b=before.get(r.slice(0,4).join(','));if(!b||b[4]!==r[4])throw Error('identity');
 const p=100*(+r[5]/+b[5]-1);
 out+=`${r.slice(0,5).join(',')},${b[5]},${r[5]},${p}\n`;
 if(r[1].startsWith('blob-')&&r[2].startsWith('wire')&&r[3].startsWith('decode'))console.log(r[0],r[1],b[5],r[5],p.toFixed(2));
}
fs.writeFileSync(`${root}/boundary-comparison.csv`,out);
