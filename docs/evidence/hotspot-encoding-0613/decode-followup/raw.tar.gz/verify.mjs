import fs from 'node:fs';
const root=process.env.WIRE_DECODE_ROOT ?? '/tmp/wire-decode-0613';
let count=0;
for(const [base,variants,expected] of [['before',['block128','block256'],1100],['before-boundary',['block128-boundary'],1804]]) {
 const read=v=>fs.readFileSync(`${root}/ic-${v}/instructions/samples.jsonl`,'utf8').trim().split('\n').map(JSON.parse);
 const key=r=>[r.profile,r.case,r.codec,r.operation].join('/');
 const b=new Map(read(base).map(r=>[key(r),r]));if(b.size!==expected)throw Error('baseline count');
 for(const v of variants) {
  const rows=read(v);if(rows.length!==expected)throw Error('candidate count');
  for(const r of rows){const prev=b.get(key(r));for(const k of ['input_sha256','payload_sha256','encoded_bytes','repetitions'])if(prev[k]!==r[k])throw Error(k);
   for(const row of [r,prev])if(row.samples_instructions.length!==3||new Set(row.samples_instructions).size!==1)throw Error('samples');
   if(r.codec==='candid'&&r.median_instructions_per_op!==prev.median_instructions_per_op)throw Error('candid changed');
   count++;
  }
 }
}
console.log(`${count} matched rows; exact input/frame identities, three equal samples, unchanged Candid controls`);
