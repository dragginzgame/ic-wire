//! Host-only lint qualification.
use std::{collections::BTreeMap, hint::black_box, time::Instant};
use serde_json::{json,Value};
fn main() {
    for count in [1,100] {
        let fields:Vec<Value> = (0..count).map(|i|json!({"name":format!("field{i}"),"value":{"k":"list","item":{"k":"u","bits":32}}})).collect();
        let fields:Vec<Value> = fields.into_iter().map(|mut f| {f["value"]=json!({"k":"ref","name":"Words"});f}).collect();
        let types=BTreeMap::from([("Reply".into(),json!({"k":"record","fields":fields})),("Words".into(),json!({"k":"list","item":{"k":"ref","name":"Word"}})),("Word".into(),json!({"k":"u","bits":32}))]);
        let roots=BTreeMap::from([("Reply".into(),json!({"k":"ref","name":"Reply"}))]);
        let acks=BTreeMap::new();
        for _ in 0..100 {black_box(ic_wire::typescript::lint_bulk_roots(&roots,&types,&acks).unwrap());}
        for sample in 0..11 {
            let start=Instant::now();
            for _ in 0..1000 {let r=ic_wire::typescript::lint_bulk_roots(black_box(&roots),black_box(&types),black_box(&acks)).unwrap();assert_eq!(r.warnings.len(),count);black_box(r);}
            println!("{count},{sample},{}", start.elapsed().as_nanos()/1000);
        }
    }
}
