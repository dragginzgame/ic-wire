//! Host-only lint qualification.
use std::{collections::BTreeMap, hint::black_box, time::Instant};
use serde_json::{json,Value};
fn main() {
    for count in [1,100] {
        let fields:Vec<Value> = (0..count).map(|i|json!({"name":format!("field{i}"),"value":{"k":"list","item":{"k":"u","bits":32}}})).collect();
        let types=BTreeMap::from([("Reply".into(),json!({"k":"record","fields":fields}))]);
        let acks=BTreeMap::new();
        for _ in 0..100 {black_box(ic_wire::typescript::lint_bulk_fields(&types,&acks).unwrap());}
        for sample in 0..11 {
            let start=Instant::now();
            for _ in 0..1000 {let r=ic_wire::typescript::lint_bulk_fields(black_box(&types),black_box(&acks)).unwrap();assert_eq!(r.warnings.len(),count);black_box(r);}
            println!("{count},{sample},{}", start.elapsed().as_nanos()/1000);
        }
    }
}
