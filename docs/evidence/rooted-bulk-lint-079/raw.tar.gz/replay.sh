#!/usr/bin/env bash
set -euo pipefail
# Run in extracted evidence with prepared offline dependencies.
mkdir before after
tar -xzf baseline.tar.gz -C before
cp -R before/. after/
(cd after && git apply ../candidate.patch)
mkdir -p after/crates/ic-wire/examples/root_measure
cp root-bench.rs after/crates/ic-wire/examples/root_measure/mod.rs
cat >> after/crates/ic-wire/Cargo.toml <<'MANIFEST'

[[example]]
name = "root-measure"
path = "examples/root_measure/mod.rs"
required-features = ["typescript"]
MANIFEST
for variant in before after; do
  cargo build --offline --locked --manifest-path "$variant/Cargo.toml" --target-dir "$PWD/$variant-target" --release -p ic-wire --features typescript --example bulk-measure
done
cargo build --offline --locked --manifest-path after/Cargo.toml --target-dir "$PWD/after-target" --release -p ic-wire --features typescript --example root-measure
for run in 1 2 3; do
  for variant in before after; do
    "$variant-target/release/examples/bulk-measure" > "$variant-$run.csv"
  done
  after-target/release/examples/root-measure > "root-$run.csv"
done
