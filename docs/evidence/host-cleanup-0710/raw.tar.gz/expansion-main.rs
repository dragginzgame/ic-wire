#![allow(dead_code)]
mod contract {pub const HEADER:usize=11;}
extern crate alloc;
#[derive(Clone,Copy)]
pub struct Limits {pub bytes:usize,pub allocation:usize,pub nodes:usize,pub depth:usize}
use std::{hint::black_box,time::Instant};
mod before;
mod after;
fn main(){
    let mut fixtures=Vec::new();
    for count in [1,100] {
        for attributed in [false,true] {
            let fields=(0..count).map(|i|if attributed {format!("#[serde(rename=\"bytes{i}\",with=\"serde_bytes\")] field{i}: Vec<u8>,")}else{format!("field{i}:u32,")}).collect::<String>();
            fixtures.push((format!("record-{count}-{attributed}"),format!("struct Example {{{fields}}}"), count));
        }
    }
    fixtures.push(("generic-100".into(), format!("struct Example<T> {{{}}}",(0..100).map(|i|format!("#[serde(rename=\"value{i}\")] field{i}:T,")).collect::<String>()),100));
    fixtures.push(("enum-100".into(),format!("enum Example {{{}}}",(0..100).map(|i|format!("#[serde(rename=\"Case{i}\")] V{i} {{#[serde(with=\"serde_bytes\")] data:Vec<u8>}},")).collect::<String>()),100));
    for source in ["struct A {#[serde(skip)] a:u8}","struct A {#[serde(rename=\"b\")] a:u8,b:u8}","#[serde(transparent)] struct A(u8,u8);","enum E {}"] {
        let input:syn::DeriveInput=syn::parse_str(source).unwrap();
        assert_eq!(before::expand(input.clone()).unwrap_err().into_compile_error().to_string(),after::expand(input).unwrap_err().into_compile_error().to_string());
    }
    println!("run,case,variant,sample,iterations,ns");
    for run in 0..3 {for (name,source,count) in &fixtures {
        let input:syn::DeriveInput=syn::parse_str(source).unwrap();
        let old=before::expand(input.clone()).unwrap().to_string();
        let new=after::expand(input.clone()).unwrap().to_string();
        assert_eq!(old,new,"{name}");
        if run==0 {std::fs::write(format!("{name}.tokens"),old).unwrap();}
        let calls:[fn(syn::DeriveInput)->syn::Result<proc_macro2::TokenStream>;2]=[before::expand,after::expand];
        for call in calls {for _ in 0..30 {black_box(call(input.clone()).unwrap());}}
        let iterations=if *count==1 {500}else{25};
        for sample in 0..11 {for v in if (sample+run)%2==0 {[0,1]}else{[1,0]} {
            let start=Instant::now();
            for _ in 0..iterations {black_box(calls[v](black_box(input.clone())).unwrap());}
            println!("{run},{name},{v},{sample},{iterations},{}",start.elapsed().as_nanos()/iterations);
        }}
    }}
}
