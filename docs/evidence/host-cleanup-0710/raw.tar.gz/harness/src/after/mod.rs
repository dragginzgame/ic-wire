use quote::format_ident;
mod native_schema;
pub fn expand(input:syn::DeriveInput)->syn::Result<proc_macro2::TokenStream>{native_schema::expand(input)}
fn fresh_ident(source: &str, base: &str) -> syn::Ident {
    let mut name = base.to_owned();
    while source.contains(&name) {
        name.push('_');
    }
    format_ident!("{name}")
}
mod metadata;
mod limits;
const MAX_SAFE_INTEGER: u64 = (1_u64 << 53) - 1;
#[derive(Clone,Copy,Debug,Eq,PartialEq)]
pub enum GenerationError {Limits,Schema,Complexity}
#[allow(unused_imports)] // The expansion-only runner does not call this export.
pub use metadata::generate_registry;
