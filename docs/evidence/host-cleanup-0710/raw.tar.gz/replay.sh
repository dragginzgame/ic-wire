#!/usr/bin/env bash
set -euo pipefail
# Extract raw.tar.gz into a disposable directory. Prepared offline dependencies required.
for operation in expansion registry; do
  cp "$operation-main.rs" harness/src/main.rs
  cargo build --offline --locked --release --manifest-path harness/Cargo.toml
  harness/target/release/wire-host-cleanup-measure > "$operation.csv"
done
