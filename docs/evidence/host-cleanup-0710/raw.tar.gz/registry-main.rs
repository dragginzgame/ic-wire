#![allow(dead_code)]
mod contract {pub const HEADER:usize=11;}
extern crate alloc;
use std::{collections::BTreeMap,hint::black_box,time::Instant};
use serde_json::{json,Value};
mod before;
mod after;
#[derive(Clone,Copy)]
pub struct Limits {pub bytes:usize,pub allocation:usize,pub nodes:usize,pub depth:usize}
fn main(){
    println!("run,case,variant,sample,iterations,ns");
    for run in 0..3 {for count in [1,100,1000] {
        let types:BTreeMap<String,Value>=(0..count).map(|i|(format!("Node{i}"),json!({"k":"record","fields":[
            {"name":"__proto__","value":{"k":"u","bits":32}},
            {"name":"quote\"slash/é","value":{"k":"bytes"}},
            {"name":"next","value":{"k":"option","item":{"k":"ref","name":format!("Node{i}")}}}
        ]}))).collect();
        let methods=vec![json!({"name":"query","mode":"query","id":"17","request":{"k":"ref","name":"Node0"},"response":{"k":"result","ok":{"k":"ref","name":"Node0"},"err":{"k":"text"}},"requestBytes":4096,"responseBytes":8192,"requestNodes":1000,"responseNodes":2000,"requestDepth":64,"responseDepth":32})];
        let old=before::generate_registry(&types,&methods,"./runtime.js").unwrap();
        let new=after::generate_registry(&types,&methods,"./runtime.js").unwrap();
        assert_eq!(old,new);
        if run==0 {std::fs::write(format!("registry-{count}.ts"),old).unwrap();}
        for _ in 0..30 {black_box(before::generate_registry(&types,&methods,"./runtime.js").unwrap());black_box(after::generate_registry(&types,&methods,"./runtime.js").unwrap());}
        let iterations=if count==1 {1000}else if count==100 {100}else{10};
        for sample in 0..11 {for v in if (sample+run)%2==0 {[0,1]}else{[1,0]} {
            let start=Instant::now();
            for _ in 0..iterations {
                if v==0 {black_box(before::generate_registry(black_box(&types),black_box(&methods),"./runtime.js").unwrap());}
                else {black_box(after::generate_registry(black_box(&types),black_box(&methods),"./runtime.js").unwrap());}
            }
            println!("{run},registry-{count},{v},{sample},{iterations},{}",start.elapsed().as_nanos()/iterations);
        }}
    }}
}
