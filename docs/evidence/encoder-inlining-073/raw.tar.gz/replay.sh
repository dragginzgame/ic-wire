#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
: "${POCKET_IC_BIN:?set an explicit prepared PocketIC server}"
run="$(mktemp -d "${TMPDIR:-/tmp}/wire-encoder-replay.XXXXXX")"
cp -R source "$run/source"
cp run.py analyze.py encode-before.rs "$run/"
export CARGO_TARGET_DIR="$run/target-native"
python3 "$run/run.py"
python3 "$run/analyze.py"
printf 'Evidence: %s\n' "$run"
