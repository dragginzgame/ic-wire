from pathlib import Path
import subprocess, json, hashlib
p=Path(__file__).parent;s=p/'source'
base=(p/'encode-before.rs').read_text()
results=json.loads((p/'sizes.json').read_text())
for variant in ['encode-auto']:
 text=base
 text=text.replace('#[cfg_attr(target_arch = "wasm32", inline(always))]', '')
 (s/'crates/ic-wire/src/native/encode/mod.rs').write_text(text)
 for cohort in ['derive-scale-1','derive-scale']:
  cmd=['cargo','build','--locked','--offline','-p','ic-wire-benchmarks','--example','codec-wasm','--target','wasm32-unknown-unknown','--profile','evaluation','--features','wire,'+cohort,'--message-format=json']
  with (p/(variant+'-'+cohort+'.jsonl')).open('w') as log:subprocess.run(cmd,cwd=s,stdout=log,check=True)
  rows=[json.loads(x) for x in (p/(variant+'-'+cohort+'.jsonl')).read_text().splitlines()]
  wasm=next(Path(f) for r in rows if r.get('reason')=='compiler-artifact' and r['target']['name']=='codec-wasm' for f in r['filenames'] if f.endswith('.wasm'))
  data=wasm.read_bytes();(p/(variant+'-'+cohort+'.wasm')).write_bytes(data)
  i=8;code=0
  while i<len(data):
   kind=data[i];i+=1;n=0;shift=0
   while True:
    b=data[i];i+=1;n|=(b&127)<<shift;shift+=7
    if b<128:break
   if kind==10:code=n
   i+=n
  result=dict(variant=variant,cohort=cohort,total=len(data),code=code,sha256=hashlib.sha256(data).hexdigest());results.append(result);print(result,flush=True)
  (p/'sizes.json').write_text(json.dumps(results,indent=2)+'\n')
