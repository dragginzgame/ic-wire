#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export CARGO_TARGET_DIR="$PWD/target"
: "${POCKET_IC_BIN:?set an explicit prepared PocketIC server}"
python3 run.py
cp parser-before.rs source/crates/ic-wire/src/native/parser/mod.rs
python3 encode.py
cp encode-before.rs source/crates/ic-wire/src/native/encode/mod.rs
python3 profiles.py
for experiment in encode profile; do
    cp "instructions-$experiment.rs" source/crates/ic-wire-benchmarks/examples/instructions/mod.rs
    if [[ "$experiment" == encode ]]; then variant=encode-auto; else variant=opt-s; fi
    for cohort in derive-scale-1 derive-scale; do
        output="$PWD/replay-$experiment-$cohort"
        mkdir "$output"
        cp "baseline-$cohort.wasm" "$output/baseline-wire.wasm"
        cp "$variant-$cohort.wasm" "$output/$variant-wire.wasm"
        cargo run --locked --offline --manifest-path source/Cargo.toml -p ic-wire-benchmarks --example codec-instructions --features "wire,candid,ic,$cohort" -- "$output"
    done
done
