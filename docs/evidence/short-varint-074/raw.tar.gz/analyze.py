from pathlib import Path
import json,csv
p=Path(__file__).parent;results=[]
for cohort in ['standard','toko','bulk','one','hundred']:
 f=p/cohort/'instructions/samples.jsonl'
 if not (p/cohort/'instructions/identity.json').exists():continue
 rows=[json.loads(x) for x in f.read_text().splitlines()]
 by={(r['profile'],r['case'],r['codec'],r['operation']):r for r in rows}
 for r in rows:
  if not r['profile'].endswith('-candidate'):continue
  profile=r['profile'].removesuffix('-candidate');b=by[profile+'-baseline',r['case'],r['codec'],r['operation']]
  assert all(r[k]==b[k] for k in ['input_sha256','payload_sha256','encoded_bytes','repetitions'])
  a=b['median_instructions_per_op'];z=r['median_instructions_per_op']
  results.append(dict(cohort=cohort,profile=profile,case=r['case'],codec=r['codec'],operation=r['operation'],before=a,after=z,change_pct=100*(z/a-1)))
 for profile in ['evaluation','benchmark-speed']:
  for op in ['encode-fresh','decode-owned-or-labelled-borrowed','encode-reuse']:
   selected=[r for r in results if r['cohort']==cohort and r['profile']==profile and r['operation']==op]
   if selected:
    lo=min(selected,key=lambda r:r['change_pct']);hi=max(selected,key=lambda r:r['change_pct'])
    print(cohort,profile,op,round(lo['change_pct'],3),round(hi['change_pct'],3),hi['case'],hi['before'],hi['after'])
if results:
 with (p/'instructions.csv').open('w') as f:
  w=csv.DictWriter(f,fieldnames=results[0]);w.writeheader();w.writerows(results)
 print('Matched rows:',len(results))
