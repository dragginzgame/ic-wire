#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
: "${POCKET_IC_BIN:?set an explicit prepared PocketIC server}"
run="$(mktemp -d "${TMPDIR:-/tmp}/wire-short-varint.XXXXXX")"
cp -R source "$run/source"
cp run.py extra.py instructions.py analyze.py parser-before.rs parser-candidate.rs "$run/"
export CARGO_TARGET_DIR="$run/target-native"
python3 "$run/run.py"
cargo test --locked --offline --manifest-path "$run/source/Cargo.toml" -p ic-wire --lib --test native
python3 "$run/instructions.py"
python3 "$run/extra.py"
python3 "$run/analyze.py"
printf 'Evidence: %s\n' "$run"
