from pathlib import Path
import subprocess
p=Path(__file__).parent
for cohort,features in [('standard',''),('one','derive-scale-1'),('hundred','derive-scale')]:
 cmd=['cargo','run','--locked','--offline','--manifest-path',str(p/'source/Cargo.toml'),'-p','ic-wire-benchmarks','--example','codec-instructions','--features','wire,candid,ic'+(','+features if features else ''),'--',str(p/cohort)]
 with (p/cohort/'instructions.log').open('w') as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
 print('IC complete: '+cohort,flush=True)
