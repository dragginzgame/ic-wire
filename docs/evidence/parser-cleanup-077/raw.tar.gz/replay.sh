#!/usr/bin/env bash
set -euo pipefail
: "${POCKET_IC_BIN:?Select an explicitly prepared compatible PocketIC server}"
archive="$(cd "$(dirname "$0")" && pwd)"
work="$(mktemp -d)"
cp -R "$archive/driver" "$work/source"
cd "$work/source"
export CARGO_TARGET_DIR="$work/target" CARGO_NET_OFFLINE=true RUSTUP_AUTO_INSTALL=0
rustc -Vv > "$work/compiler.txt"
for variant in before after; do
    cp "$archive/parser-$variant.rs" crates/ic-wire/src/native/parser/mod.rs
    for cohort in standard derive-scale-1 derive-scale; do
        out="$work/$cohort/$variant"
        mkdir -p "$out"
        features=wire
        [ "$cohort" = standard ] || features="wire,$cohort"
        for profile in evaluation benchmark-speed; do
            cargo build --locked --offline -p ic-wire-benchmarks --example codec-wasm --target wasm32-unknown-unknown --profile "$profile" --features "$features"
            cp "$CARGO_TARGET_DIR/wasm32-unknown-unknown/$profile/examples/codec_wasm.wasm" "$out/$profile-wire.wasm"
            perl "$archive/sections.pl" "$out/$profile-wire.wasm" >> "$work/sections.txt"
        done
    done
    cargo run --locked --offline -p ic-wire-benchmarks --example codec-instructions --features wire,candid,ic -- "$work/standard/$variant"
done
perl "$archive/compare.pl" "$work/standard/before/instructions/samples.jsonl" "$work/standard/after/instructions/samples.jsonl" > "$work/instructions.csv"
printf 'Replayed evidence: %s\n' "$work"
