use strict;
use warnings;
use Digest::SHA qw(sha256_hex);
for my $path (@ARGV) {
    open my $f, '<:raw', $path or die $!;
    local $/; my $bytes=<$f>; my $pos=8;
    print "$path total=",length($bytes)," sha=",sha256_hex($bytes),"\n";
    while($pos<length($bytes)) {
        my $id=ord(substr($bytes,$pos++,1)); my ($n,$shift)=(0,0);
        while(1) { my $b=ord(substr($bytes,$pos++,1)); $n |= ($b&127)<<$shift; last unless $b&128; $shift+=7; }
        my $data=substr($bytes,$pos,$n); $pos+=$n;
        print "$id $n ",sha256_hex($data),"\n";
    }
}
