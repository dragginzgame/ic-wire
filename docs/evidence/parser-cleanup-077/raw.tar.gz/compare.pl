use strict;
use warnings;
use JSON::PP;
my ($before,$after)=@ARGV;
sub rows {
    my ($path)=@_; open my $f,'<',$path or die $!; my %rows;
    while(<$f>) { my $r=decode_json($_); $rows{join('/',@$r{qw(profile case codec operation)})}=$r; }
    return \%rows;
}
my $b=rows($before); my $a=rows($after);
die 'row count' unless keys(%$a)==keys(%$b);
print "profile,case,codec,operation,before,after,percent\n";
for my $key(sort keys %$b) {
    my $x=$b->{$key}; my $y=$a->{$key} or die "missing $key";
    for my $f(qw(input_sha256 payload_sha256 encoded_bytes repetitions)) { die "$key/$f mismatch" unless $x->{$f} eq $y->{$f}; }
    my $old=$x->{median_instructions_per_op}; my $new=$y->{median_instructions_per_op};
    print join(',',@$x{qw(profile case codec operation)},$old,$new,$old ? 100*($new-$old)/$old : 0),"\n";
}
