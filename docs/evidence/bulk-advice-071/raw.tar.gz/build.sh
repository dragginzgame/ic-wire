#!/usr/bin/env bash
set -euo pipefail
r=${WIRE_BULK_ROOT:?}
export CARGO_TARGET_DIR=${CARGO_TARGET_DIR:-$r/target} CARGO_NET_OFFLINE=true
for variant in before after; do
 cd "$r/$variant"
 find crates -name '*.rs' -exec touch {} +
 extra=bulk
 if [ "$variant" = before ]; then extra=bulk,bulk-baseline; fi
 mkdir -p "$r/ic-$variant"
 for profile in evaluation benchmark-speed; do
  cargo build --locked --offline --profile "$profile" -p ic-wire-benchmarks --example codec-wasm --target wasm32-unknown-unknown --features "wire,$extra" > "$r/$variant-$profile.log" 2>&1
  cp "$CARGO_TARGET_DIR/wasm32-unknown-unknown/$profile/examples/codec_wasm.wasm" "$r/ic-$variant/$profile-wire.wasm"
  if [ "$variant" = before ]; then
   cargo build --locked --offline --profile "$profile" -p ic-wire-benchmarks --example codec-wasm --target wasm32-unknown-unknown --features "candid,$extra" > "$r/candid-$profile.log" 2>&1
   cp "$CARGO_TARGET_DIR/wasm32-unknown-unknown/$profile/examples/codec_wasm.wasm" "$r/$profile-candid.wasm"
  fi
  cp "$r/$profile-candid.wasm" "$r/ic-$variant/$profile-candid.wasm"
 done
 cargo build --locked --offline -p ic-wire-benchmarks --example codec-instructions --features "wire,candid,ic,$extra" > "$r/$variant-driver.log" 2>&1
 cp "$CARGO_TARGET_DIR/debug/examples/codec-instructions" "$r/$variant-driver"
done
# Unchanged 100-record consumer: new packed impl and host lint are unused.
for variant in before after; do
 cd "$r/$variant"
 find crates -name '*.rs' -exec touch {} +
 cargo build --locked --offline --profile benchmark-speed -p ic-wire-benchmarks --example codec-wasm --target wasm32-unknown-unknown --features wire,derive-scale > "$r/$variant-control.log" 2>&1
 cp "$CARGO_TARGET_DIR/wasm32-unknown-unknown/benchmark-speed/examples/codec_wasm.wasm" "$r/$variant-control.wasm"
done
