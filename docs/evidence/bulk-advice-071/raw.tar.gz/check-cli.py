import json,pathlib,subprocess
r=pathlib.Path('/tmp/wire-bulk-071'); schema=r/'schemas.json';acks=r/'acknowledged.json'
schema.write_text(json.dumps({'Samples':{'k':'list','item':{'k':'i','bits':8}}}))
exe=pathlib.Path('/home/adam/projects/ic-wire/target/debug/examples/bulk-lint')
def run(args,code,text):
 p=subprocess.run([str(exe),str(schema),*args],capture_output=True,text=True)
 assert p.returncode==code,(p.returncode,p.stderr)
 assert text in p.stderr,p.stderr
run([],0,'/Samples: consider Packed<i8>')
run(['--deny-warnings'],1,'/Samples: consider Packed<i8>')
acks.write_text(json.dumps({'/Samples':'Tiny fixed consumer input; ordinary admission is intentional'}))
run(['--acknowledgements',str(acks),'--deny-warnings'],0,'')
acks.write_text(json.dumps({'/Old':'Old field'}))
run(['--acknowledgements',str(acks),'--deny-warnings'],1,'stale acknowledgement')
acks.write_text(json.dumps({'/Samples':''}))
run(['--acknowledgements',str(acks)],1,'invalid bulk-lint input')
print('CLI advisory, strict, acknowledged, stale and invalid reason checks passed')
