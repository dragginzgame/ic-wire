#!/usr/bin/env bash
set -euo pipefail
source_dir=$(cd -- "$(dirname -- "$0")" && pwd)
export WIRE_BULK_ROOT=${1:?absolute fresh directory}
: "${POCKET_IC_BIN:?prepared PocketIC 16.1.0 binary}"
mkdir "$WIRE_BULK_ROOT"
export CARGO_TARGET_DIR="$WIRE_BULK_ROOT/target" CARGO_NET_OFFLINE=true
for variant in before after; do
 tar -xf "$source_dir/$variant.tar" -C "$WIRE_BULK_ROOT"
done
bash "$source_dir/build.sh"
for variant in before after; do
 "$WIRE_BULK_ROOT/$variant-driver" "$WIRE_BULK_ROOT/ic-$variant" > "$WIRE_BULK_ROOT/ic-$variant.log" 2>&1
done
python3 "$source_dir/analyze.py" > "$WIRE_BULK_ROOT/results.txt"
cp "$source_dir/host.rs" "$WIRE_BULK_ROOT/after/crates/ic-wire/examples/host_bulk_lint.rs"
cargo run --manifest-path "$WIRE_BULK_ROOT/after/Cargo.toml" --locked --offline -p ic-wire --features typescript --profile benchmark-speed --example host_bulk_lint > "$WIRE_BULK_ROOT/host.csv" 2> "$WIRE_BULK_ROOT/host-build.log"
