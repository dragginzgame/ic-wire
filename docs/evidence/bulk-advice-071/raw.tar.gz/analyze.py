import csv,json,pathlib,os
r=pathlib.Path(os.environ.get('WIRE_BULK_ROOT','/tmp/wire-bulk-071'))
def load(v):
 return [json.loads(x) for x in (r/f'ic-{v}/instructions/samples.jsonl').read_text().splitlines()]
def key(x): return tuple(x[k] for k in ['profile','case','codec','operation'])
before={key(x):x for x in load('before')};after=load('after');assert len(before)==len(after)
with (r/'comparison.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['profile','case','codec','operation','before_bytes','after_bytes','before_instructions','after_instructions','percent'])
 for x in after:
  b=before[key(x)]
  assert x['input_sha256']==b['input_sha256']
  assert len(set(x['samples_instructions']))==len(set(b['samples_instructions']))==1
  assert len(x['samples_instructions'])==len(b['samples_instructions'])==3
  if x['codec']=='candid': assert x['payload_sha256']==b['payload_sha256'] and x['median_instructions_per_op']==b['median_instructions_per_op']
  bv=b['median_instructions_per_op'];av=x['median_instructions_per_op']
  w.writerow([*key(x),b['encoded_bytes'],x['encoded_bytes'],bv,av,100*(av/bv-1) if bv else 0])
  if x['profile']=='benchmark-speed' and x['case'] in ['i8-wide-0','i8-wide-1','i8-wide-128','i8-wide-16384','i16-wide-16384','u64-wide-16384'] and x['operation'] in ['encode-fresh','decode-owned-or-labelled-borrowed']:
   print(*key(x),b['encoded_bytes'],x['encoded_bytes'],bv,av)
def size(p):
 b=p.read_bytes();i=8;code=0
 while i<len(b):
  tag=b[i];i+=1;n=0;s=0
  while True:
   v=b[i];i+=1;n|=(v&127)<<s;s+=7
   if v<128:break
  if tag==10:code=n
  i+=n
 return dict(total=len(b),code=code)
sizes={v:{p.name:size(p) for p in (r/f'ic-{v}').glob('*.wasm')} for v in ['before','after']}
sizes['unchanged_100_records']={v:size(r/f'{v}-control.wasm') for v in ['before','after']}
assert (r/'before-control.wasm').read_bytes()==(r/'after-control.wasm').read_bytes()
(r/'wasm.json').write_text(json.dumps(sizes,indent=2)+'\n');print('Wasm',sizes);print('rows',len(after))
