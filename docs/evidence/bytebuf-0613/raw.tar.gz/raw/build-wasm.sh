#!/usr/bin/env bash
set -euo pipefail
variant="${1:?variant}"
source="${2:?source root}"
r=/tmp/wire-bytebuf-0613
cd "$source"
export CARGO_TARGET_DIR=/tmp/wire-hotspots-0613/build CARGO_NET_OFFLINE=true
find crates -name '*.rs' -exec touch {} +
for profile in evaluation benchmark-speed; do
 cargo build --locked --offline --profile "$profile" -p ic-wire-benchmarks --example codec-wasm --target wasm32-unknown-unknown --features wire,hotspots > "$r/$variant-$profile.log" 2>&1
 cp "$CARGO_TARGET_DIR/wasm32-unknown-unknown/$profile/examples/codec_wasm.wasm" "$r/$variant-$profile.wasm"
done
