#!/usr/bin/env bash
set -euo pipefail
archive="$(cd "$(dirname "$0")" && pwd)"
work="$(mktemp -d)"
cp -R "$archive/source" "$work/source"
cd "$work/source"
export CARGO_TARGET_DIR="$work/target" CARGO_NET_OFFLINE=true RUSTUP_AUTO_INSTALL=0
for variant in before after; do
    rm -rf "$work/source/crates/ic-wire/src/typescript"
    if [ "$variant" = before ]; then
        cp -R "$archive/typescript-before" crates/ic-wire/src/typescript
        cp "$archive/derive-before.rs" crates/ic-wire-derive/src/native_schema/mod.rs
        cp "$archive/main-before.rs" crates/ic-wire/examples/typescript_conformance/mod.rs
    else
        cp -R "$archive/source/crates/ic-wire/src/typescript" crates/ic-wire/src/typescript
        cp "$archive/source/crates/ic-wire-derive/src/native_schema/mod.rs" crates/ic-wire-derive/src/native_schema/mod.rs
        cp "$archive/source/crates/ic-wire/examples/typescript_conformance/mod.rs" crates/ic-wire/examples/typescript_conformance/mod.rs
    fi
    cargo build --locked --offline -p ic-wire --features typescript --profile benchmark-speed --example typescript-conformance
    for n in 1 2 3; do "$CARGO_TARGET_DIR/benchmark-speed/examples/typescript-conformance" "$work/$variant-$n"; done
    for profile in evaluation benchmark-speed; do
        cargo build --locked --offline -p ic-wire-benchmarks --example codec-wasm --target wasm32-unknown-unknown --profile "$profile" --features wire,derive-scale-1
        cp "$CARGO_TARGET_DIR/wasm32-unknown-unknown/$profile/examples/codec_wasm.wasm" "$work/$variant-$profile.wasm"
    done
done
for profile in evaluation benchmark-speed; do cmp "$work/before-$profile.wasm" "$work/after-$profile.wasm"; done
printf 'Replayed evidence: %s\n' "$work"
