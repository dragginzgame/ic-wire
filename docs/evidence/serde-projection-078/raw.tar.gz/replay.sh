#!/usr/bin/env bash
set -euo pipefail
# Run inside an extracted evidence directory. Prepared offline dependencies required.
mkdir before after
tar -xzf baseline.tar.gz -C before
cp -R before/. after/
(cd after && git apply ../candidate.patch)
for variant in before after; do
  cargo build --offline --locked --manifest-path "$variant/Cargo.toml" --target-dir "$PWD/$variant-target" -p ic-wire --features typescript --example typescript-conformance
done
for run in 1 2 3; do
  for variant in before after; do
    "$variant-target/debug/examples/typescript-conformance" "$PWD/$variant-$run"
  done
done
