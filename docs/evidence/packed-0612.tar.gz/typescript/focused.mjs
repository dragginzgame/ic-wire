import assert from 'node:assert/strict';
import {performance} from 'node:perf_hooks';
import {createCodec as before} from './before/runtime.js';
import {createCodec as after} from './after/runtime.js';
const samples=[];
let sink;
for (let run=1;run<=3;run++) for (const [word,ctor] of Object.entries({i16:Int16Array,u16:Uint16Array,i32:Int32Array,u32:Uint32Array,i64:BigInt64Array,u64:BigUint64Array,hash32:Uint8Array,boundedI16:Int16Array})) for (const length of [0,1,2,8,128,16384]) {
  if (process.argv[2] && process.argv[2] !== word) continue;
  const value = new ctor(word === 'hash32' ? length * 32 : length).fill(word.endsWith('64') ? 1n : 1), schema=word === 'boundedI16' ? {k:'packed-i16',max:length} : {k:'packed',word};
  const meta={id:'1',request:schema,response:schema,requestBytes:value.byteLength+32,responseBytes:value.byteLength+32,requestNodes:16,responseNodes:16,requestDepth:8,responseDepth:8};
  const old=before(meta), next=after(meta), bytes=old.encodeRequest(value);
  assert.deepEqual(next.encodeRequest(value),bytes);
  assert.deepEqual(next.decodeRequest(bytes),value);
  for (const [label,codec] of run % 2 === 1 ? [['before',old],['after',next]] : [['after',next],['before',old]]) {
    for (const op of ['encode','decode']) {
      const call=op==='encode'?()=>codec.encodeRequest(value):()=>codec.decodeRequest(bytes);
      for(let i=0;i<5000;i++) sink=call();
      global.gc?.();
      let reps=1;
      while (reps<1048576) { const t=performance.now();for(let i=0;i<reps;i++)sink=call();if(performance.now()-t>=5)break;reps*=2; }
      const ns=[];
      for(let s=0;s<11;s++) {const t=performance.now();for(let i=0;i<reps;i++)sink=call();ns.push((performance.now()-t)*1e6/reps);}
      const sorted=[...ns].sort((a,b)=>a-b);
      samples.push({run,word,length,label,op,reps,samples_ns:ns,median_ns:sorted[5],bytes:bytes.length});
    }
  }
}
console.log(JSON.stringify({node:process.version,platform:process.platform,arch:process.arch,samples,sink:sink.length}));
