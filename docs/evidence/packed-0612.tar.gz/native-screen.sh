#!/usr/bin/env bash
set -euo pipefail
r=/tmp/wire-packed-0612
export GIT_DIR=/home/adam/projects/ic-wire/.git GIT_WORK_TREE=/home/adam/projects/ic-wire
printf 'variant,total_bytes,code_bytes,sha256\n' > "$r/wasm-screen.csv"
# Compile everything before timing; isolated directories prevent stale reuse.
for variant in before candidate; do
 cd "$r/$variant"
 export CARGO_TARGET_DIR="$r/target-$variant"
 cargo build --locked --profile evaluation -p ic-wire-benchmarks --example codec-wasm --target wasm32-unknown-unknown --features wire,bulk > "$r/$variant-wasm.log" 2>&1
 f="$CARGO_TARGET_DIR/wasm32-unknown-unknown/evaluation/examples/codec_wasm.wasm"
 cp "$f" "$r/$variant.wasm"
 code=$(/tmp/wire-packed-production-0611/inline-target/debug/examples/codec-report --code-size "$f")
 hash=$(sha256sum "$f")
 printf '%s,%s,%s,%s\n' "$variant" "$(wc -c < "$f")" "$code" "${hash%% *}" >> "$r/wasm-screen.csv"
 cargo bench --locked --profile evaluation -p ic-wire-benchmarks --bench suite --features wire,candid,bulk --no-run --message-format=json > "$r/$variant-build.jsonl" 2> "$r/$variant-build.log"
done
for run in 1 2; do
 for variant in before candidate; do
  cd "$r/$variant"
  binary=$(python3 -c 'import json,sys; rows=[json.loads(x) for x in open(sys.argv[1])]; print(next(x["executable"] for x in rows if x.get("executable") and x.get("target",{}).get("name")=="suite"))' "$r/$variant-build.jsonl")
  "$binary" "$r/$variant-native-$run" evaluation 11 2 > "$r/$variant-native-$run.log" 2>&1
 done
done
